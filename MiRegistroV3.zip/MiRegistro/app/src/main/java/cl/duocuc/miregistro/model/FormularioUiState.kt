package cl.duocuc.miregistro.model

enum class NivelExperiencia (val etiqueta: String){
    PRINCIPIANTE("Principiante"),
    INTERMEDIO("Intermedio"),
    AVANZADO("Avanzado")
}

//Estructura de datos de la pantalla
data class FormularioUiState(
    //valores de los campos
    val nombre: String = "",
    val correo: String = "",
    val contrasena: String = "",
    val nivel: NivelExperiencia = NivelExperiencia.PRINCIPIANTE,
    val recibirNoticias: Boolean = false,
    val aceptarTerminos: Boolean = false,
    //visibilidad de la clave
    val contrasenaVisible: Boolean = false,
    //Error de validacion
    val errorNombre: String? = null,
    val errorCorreo: String? = null,
    val errorContrasena: String? = null,
    val errorTerminos: String? = null,
    //resultado
    val registroExitoso: Boolean = false
)