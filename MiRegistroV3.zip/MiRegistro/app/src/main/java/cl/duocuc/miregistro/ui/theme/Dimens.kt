package cl.duocuc.miregistro.ui.theme

import androidx.compose.ui.unit.dp

object Dimens {
    //espaciados (margin/padding/gap)
    val espacioMini = 4.dp
    val espacioChico = 8.dp
    val espacioMedio = 16.dp
    val espacioGrande = 24.dp
    val espacioPantalla = 20.dp
    //Botones
    val alturaBoton = 52.dp
    val radioBoton = 14.dp
    val bordeBoton = 2.dp
    val elevacionBoton = 4.dp
    //campos de texto
    val radioCampo = 12.dp
    //CARD
    val radioTarjeta = 20.dp
    val elevacionTarjeta = 2.dp
    //Imagenes
    val altoBanner = 200.dp
    val altoPortada = 180.dp
    val tamanoAvatar = 120.dp
    val bordeAvatar = 4.dp
    val tamanoIcono = 20.dp
}