package cl.duocuc.miregistro.viewmodel

import androidx.compose.runtime.MutableState
import androidx.lifecycle.ViewModel
import cl.duocuc.miregistro.model.FormularioUiState
import cl.duocuc.miregistro.model.NivelExperiencia
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update


class FormularioViewModel: ViewModel(){
    //Creamos la privada y mutable
    private val _uiState = MutableStateFlow(FormularioUiState())
    //publica y solo lectura
    val uiState: StateFlow<FormularioUiState> = _uiState.asStateFlow()

    //eventos de los campos de pantalla
    fun onNombreCambia(valor: String){

        _uiState.update { it.copy(nombre = valor, errorNombre = null, registroExitoso = false) }
    }

    fun onContrasenaCambia(valor: String){
        _uiState.update { it.copy(contrasena = valor, errorContrasena = null, registroExitoso = false) }
    }

    fun onAlternarVisibilidad(){
        _uiState.update { it.copy(contrasenaVisible = !it.contrasenaVisible) }
    }

    //eventos de los controles de seleccion
    fun onNivelSeleccionado(nivel: NivelExperiencia){
        _uiState.update { it.copy(nivel = nivel) }
    }

    fun onNoticiasCambia(valor: Boolean){
        _uiState.update { it.copy(aceptarTerminos = valor, errorTerminos = null) }
    }

    //botones
    //limpiar
    fun onLimpiar(){
        _uiState.value = FormularioUiState()
    }

    //registrar
    fun onRegistrase(){
        val estado = _uiState.value

        //validaciones
        val errorNombre = if(estado.nombre.isBlank())"El nombre es obligatorio" else null
        val errorCorreo = if(!estado.correo.contains("@")|| !estado.correo.contains("."))
            "Debe ingresar un correo con formato valido" else null
        val errorContrasena = if(estado.contrasena.length <6) "Minimo 6 caracteres" else null
        val errorTerminos = if(!estado.aceptarTerminos)"Debe aceptar terminos" else null


    }
}